<template>
  <NavBar :links="links">
    <template #nav-button="{ label }">
      <span v-if="label === 'boutique'"><strong>{{ label }}</strong></span>
      <span v-else-if="label === 'banque'"><img src="@/assets/bank.png" alt="bank" style="width: 20px; height: 20px;"></span>
    </template>
  </NavBar>
  <router-view></router-view>
</template>

<script setup>
/* ***************************
  IMPORTS
 *************************** */
import NavBar from "@/components/NavBar.vue";
import {ref, onMounted, computed} from "vue";
import {useShopStore} from "@/stores/shop.js";
import { useRouter } from 'vue-router'

/* ***************************
  STATE
 *************************** */
const router = useRouter()
const shopStore = useShopStore()
const links = [
  { label: "boutique", to: "/shop" },
  { label: "banque", to: "/bank" }
]

/* ***************************
  FUNCTIONS
 *************************** */
// Supprimé goTo car maintenant géré dans NavBar

/* ***************************
  HOOKS
 *************************** */
// Dès que l'appli est lancée, on va chercher la liste des virus pour la stocker dans le store
onMounted(() => {
  shopStore.getAllViruses()
})
</script>

<style scoped></style>
