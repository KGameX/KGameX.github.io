<template>
  <div>
    <h1>Solde</h1>
    <slot name="account-amount" :amount="amount">
      {{ amount }}
    </slot>
  </div>
</template>

<script>
import { computed } from 'vue'
import { useBankStore } from '@/stores/bank'

export default {
  name: 'BankAmount',
  setup() {
    const bankStore = useBankStore()
    const amount = computed(() => bankStore.currentAccount?.amount || 0)
    return {
      amount
    }
  }
}
</script>