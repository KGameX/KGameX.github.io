<template>
  <div>
    <h1>Solde</h1>
    <p>Votre solde actuel.</p>
  </div>
</template>

<script>
export default {
  name: 'BankAmount'
}
</script>