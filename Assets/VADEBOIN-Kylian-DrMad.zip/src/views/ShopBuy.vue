<template>
  <div class="shop-buy">
    <div class="left">
      <ItemsList />
    </div>
    <div class="right">
      <BasketList />
    </div>
  </div>
</template>

<script>
import ItemsList from '@/components/ItemsList.vue';
import BasketList from '@/components/BasketList.vue';

export default {
  name: 'ShopBuy',
  components: {
    ItemsList,
    BasketList
  }
}
</script>

<style scoped>
.shop-buy {
  display: flex;
}

.left {
  flex: 1;
}

.right {
  flex: 1;
}
</style>