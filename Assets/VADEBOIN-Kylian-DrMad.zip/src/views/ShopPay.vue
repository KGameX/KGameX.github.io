<template>
  <div>
    <h1>Payer une commande</h1>
    <div>
      <label for="orderUuid">UUID de la commande :</label>
      <input type="text" id="orderUuid" v-model="orderUuidInput" />
    </div>
    <div>
      <label for="transactionUuid">UUID de la transaction bancaire :</label>
      <input type="text" id="transactionUuid" v-model="transactionUuidInput" />
    </div>
    <button @click="payOrder">Payer</button>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useShopStore } from '@/stores/shop'
import ShopService from '@/services/shop.service'
import { useRouter } from 'vue-router'

const props = defineProps(['orderUuid'])
const orderUuidInput = ref(props.orderUuid || '')
const transactionUuidInput = ref('')
const shopStore = useShopStore()
const router = useRouter()

const payOrder = async () => {
  if (!shopStore.shopUser) {
    alert('Utilisateur non connecté')
    return
  }
  // Vérifier si la commande existe
  const getResponse = await ShopService.getOrder(orderUuidInput.value, shopStore.shopUser._id)
  if (getResponse.error !== 0) {
    alert(getResponse.data)
    return
  }
  // Payer la commande
  const payResponse = await ShopService.payOrder({
    uuid: orderUuidInput.value,
    userId: shopStore.shopUser._id,
    transactionUuid: transactionUuidInput.value
  })
  if (payResponse.error === 0) {
    alert('Commande payée avec succès')
    router.push({ name: 'orders' })
  } else {
    alert(payResponse.data)
  }
}
</script>