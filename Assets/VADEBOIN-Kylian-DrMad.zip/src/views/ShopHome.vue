<template>
  <div>
    <h1>Bienvenue Chez Dr. Mad</h1>
  </div>
</template>

<script>
export default {
  name: 'ShopHome'
}
</script>