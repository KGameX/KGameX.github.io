<template>
  <div class="example-container">
    <h2>Exemple d'utilisation du composant DataTable</h2>

    <h3>Table avec cases à cocher, boutons d'action et bouton de table</h3>
    <DataTable :headers="headers" :items="items" itemCheck itemButton tableButton
               @itemClicked="onItemClicked"
               @tableClicked="onTableClicked">
      <template #item-button>Acheter</template>
      <template #table-button>Commander la sélection</template>
    </DataTable>

    <h3>Table simple sans cases à cocher ni boutons</h3>
    <DataTable :headers="simpleHeaders" :items="items"></DataTable>

    <h3>Table avec seulement des boutons d'action</h3>
    <DataTable :headers="headers" :items="items" itemButton
               @itemClicked="onItemClicked">
      <template #item-button>Détails</template>
    </DataTable>

    <div v-if="selectedItem" class="result">
      <h4>Dernier item cliqué :</h4>
      <p>{{ selectedItem.virus }} - {{ selectedItem.price }}€</p>
    </div>

    <div v-if="selectedItems.length > 0" class="result">
      <h4>Items sélectionnés pour la commande :</h4>
      <ul>
        <li v-for="item in selectedItems" :key="item.virus">
          {{ item.virus }} - {{ item.price }}€
        </li>
      </ul>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import DataTable from '@/components/DataTable.vue'

const headers = ref([
  { label: "Virus", name: "virus" },
  { label: "Prix", name: "price" }
])

const simpleHeaders = ref([
  { label: "Nom", name: "virus" },
  { label: "Prix", name: "price" },
  { label: "Force", name: "strength" }
])

const items = ref([
  { virus: "grippe", price: 1000, strength: 5 },
  { virus: "covid", price: 150, strength: 5 },
  { virus: "cholera", price: 6666, strength: 20 },
])

const selectedItem = ref(null)
const selectedItems = ref([])

const onItemClicked = (item) => {
  selectedItem.value = item
  console.log('Item cliqué:', item)
}

const onTableClicked = (items) => {
  selectedItems.value = items
  console.log('Items sélectionnés:', items)
}
</script>

<style scoped>
.example-container {
  padding: 20px;
}

.result {
  margin-top: 20px;
  padding: 10px;
  background-color: #f0f0f0;
  border-radius: 5px;
}

.result h4 {
  margin-top: 0;
  color: #333;
}

.result ul {
  margin: 10px 0;
  padding-left: 20px;
}
</style>