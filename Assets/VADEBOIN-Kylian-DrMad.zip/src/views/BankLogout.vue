<template>
  <div>
    <h1>Déconnexion du compte</h1>
    <p>Vous allez être redirigé vers l'accueil de la banque.</p>
  </div>
</template>

<script setup>
import { onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useBankStore } from '@/stores/bank'

const router = useRouter()
const bankStore = useBankStore()

onMounted(() => {
  setTimeout(() => {
    bankStore.logout()
    router.push('/bank')
  }, 1000)
})
</script>