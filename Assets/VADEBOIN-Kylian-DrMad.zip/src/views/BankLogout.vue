<template>
  <div>
    <h1>Déconnexion</h1>
    <p>Vous êtes déconnecté.</p>
  </div>
</template>

<script>
export default {
  name: 'BankLogout'
}
</script>