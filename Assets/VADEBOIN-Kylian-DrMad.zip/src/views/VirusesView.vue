<template>
  <div>
    <h1>Les virus</h1>
    <span>Filtres :</span>
    <hr />
    <label for="filterpriceactive">par prix</label><input type="checkbox" v-model="filterPriceActive" id="filterpriceactive">
    <label for="filternameactive">par nom</label><input type="checkbox" v-model="filterNameActive" id="filternameactive">
    <label for="filterstockactive">par stock</label><input type="checkbox" v-model="filterStockActive" id="filterstockactive">
    <hr />
    <table>
      <tbody>
      <tr>
        <td v-if="filterPriceActive">
          <label for="filterprice">prix inférieur à : </label><input v-model="priceFilter" id="filterprice">
        </td>
        <td v-if="filterNameActive">
          <label for="filtername">nom contient : </label><input v-model="nameFilter" id="filtername">
        </td>
        <td v-if="filterStockActive">
          <label for="filterstock">en stock</label><input type="checkbox" v-model="stockFilter" id="filterstock">
        </td>
      </tr>
      </tbody>
    </table>
    <hr />

    <!-- version avec liste séparée : décommenter pour tester

    <p>Liste filtrée par prix</p>
    <ul>
      <li v-for="(virus, index) in filterVirusesByPrice" :key="index">{{virus.name}} : {{virus.price}}</li>
    </ul>
    <hr />
    <p>Liste filtrée par nom</p>
    <ul>
      <li v-for="(virus, index) in filterVirusesByName" :key="index">{{virus.name}} : {{virus.price}}</li>
    </ul>
    <hr />
    <p>Liste filtrée par stock</p>
    <table>
      <tbody>
      <tr>
        <th>Nom</th><th>Prix</th>
      </tr>
      <tr v-for="(virus, index) in filterVirusesByStock" :key="index">
        <td>{{virus.name}}</td>
        <td>{{virus.price}}</td>
      </tr>
      </tbody>
    </table>

    -->

    <!-- version avec filtre multi-critères -->
    <CheckedList :data="filterViruses"
                 :fields="['name', 'price']"
                 item-check
                 :item-button="{show: true, text:'Info'}"
                 :list-button="{show: true, text:'Select'}"
                 :checked="checked"
                 @checked-changed="changeSelection($event)"
                 @item-button-clicked="showVirusInfos($event)"
                 @list-button-clicked="showVirusNames()"
    >
    </CheckedList>
  </div>
</template>

<script setup>
/* ***************************
  IMPORTS
 *************************** */
import CheckedList from "@/components/CheckedList.vue";
import {ref, computed, watch} from "vue"
import {useShopStore} from "@/stores/shop.js";

/* ***************************
  STATE
 *************************** */
const shopStore = useShopStore()
const priceFilter = ref(0)
const nameFilter = ref('')
const stockFilter = ref(true)
const filterPriceActive = ref(false)
const filterNameActive = ref(false)
const filterStockActive = ref(false)
const selected = ref([])

/* ***************************
  COMPUTED
 *************************** */
const checked = computed(() => {
  let tab = []
  filterViruses.value.forEach(v => {
    // find the index of virus v in this.viruses
    let idx = shopStore.viruses.findIndex(el => el == v)
    // if idx is in selected, push true, else push false
    if (selected.value.includes(idx)) {
      tab.push(true)
    }
    else {
      tab.push(false)
    }
  })
  return tab
})

const filterVirusesByPrice = computed(() => {
  // active filter => get filtered list
  if (filterPriceActive.value) {
    let price = parseInt(priceFilter.value)
    if (isNaN(price)) return []
    if (price > 0) return shopStore.viruses.filter(v => v.price < price)
  }
  return shopStore.viruses
})

const filterVirusesByName = computed(() => {
  // active filter => get filtered list
  if (filterNameActive.value) {
    if (nameFilter.value) return shopStore.viruses.filter(v => v.name.includes(nameFilter.value))
  }
  return shopStore.viruses
})

const filterVirusesByStock = computed(() => {
  // active filter => get filtered list
  if (filterStockActive.value) {
    if (stockFilter.value) return shopStore.viruses.filter(v => v.stock > 0)
  }
  return shopStore.viruses
})

/**
 * filterViruses ne peut pas réutiliser les 3 fonctions précédentes puisqu'elles
 * utilisent toutes comme base shopStore.viruses. Or, s'il y a plus de un filtre,
 * il faut faire un filtrage cumulatif, donc reprendre le résultat du filtre précédent
 * @type {ComputedRef<[]>}
 */
const filterViruses = computed(() => {
  let list = shopStore.viruses
  if (filterPriceActive.value) {
    let price = parseInt(priceFilter.value)
    if ((!isNaN(price)) && (price > 0)) {
      list = list.filter(v => v.price < price)
    }
  }
  if (filterNameActive.value) {
    if (nameFilter.value) list = list.filter(v => v.name.includes(nameFilter.value))
  }
  if (filterStockActive.value) {
    if (stockFilter.value) list = list.filter(v => v.stock > 0)
  }
  return list
})

/* ***************************
  FUNCTIONS
 *************************** */
function changeSelection(idx) {
  // get the virus in the filtered list
  let v = filterViruses.value[idx]
  // search its index in this.viruses
  let i = shopStore.viruses.findIndex(el => el === v)
  // if i is in selected, remove it
  let j = selected.value.findIndex(el => el === i)
  if (j !== -1) {
    selected.value.splice(j,1)
  }
  else {
    selected.value.push(i)
  }
}

function showVirusInfos(idx) {
  let v = filterViruses.value[idx]
  let msg = v.name+ ", stock = "+v.stock+", for sell = "+v.sold
  alert(msg)
}

function showVirusNames() {
  let msg = ""
  selected.value.forEach(idx => {
    msg += shopStore.viruses[idx].name+" "
  })
  alert(msg)
}

/* ***************************
  WATCHERS
 *************************** */
/* Pour supprimer de selected les virus sélectionnés non présents dans la liste
   filtrée, il faut pouvoir déclencher un traitement lorsque cette dernière change.
   Or, elle est du type computed et ne permet donc pas de modifier en même temps
   selected. Cette dernière ne peut pas être elle-même computed puisque son contenu
   doit pouvoir être mis à jour via la fonction changeSelection()
   La solution la plus simple consiste à utiliser un watcher (exceptionnellement)
   pour surveiller l'état de filterViruses et s'il change, modifier éventuellement selected.
 */
watch(filterViruses, () => {
  selected.value = selected.value.filter(idx => {
    let v = shopStore.viruses[idx]
    return filterViruses.value.find(el => el === v)
  })
})

</script>
