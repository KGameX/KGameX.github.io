<template>
  <div>
    <h1>
      <slot>Débit / Virement</slot>
    </h1>
    <div>
      <label for="amount">Montant:</label>
      <input id="amount" type="number" v-model="amount" min="0" step="0.01" />
    </div>
    <div>
      <input id="destinataire" type="checkbox" v-model="hasDestinataire" />
      <label for="destinataire">Destinataire</label>
      <input v-if="hasDestinataire" type="text" v-model="destinataire" placeholder="Numéro de compte destinataire" />
    </div>
    <button @click="valider">Valider</button>
    <p v-if="successMessage">{{ successMessage }}</p>
  </div>
</template>

<script>
import { ref } from 'vue'
import { useBankStore } from '@/stores/bank'

export default {
  name: 'BankOperation',
  setup() {
    const bankStore = useBankStore()
    const amount = ref('')
    const hasDestinataire = ref(false)
    const destinataire = ref('')
    const successMessage = ref('')

    const valider = async () => {
      const amt = parseFloat(amount.value)
      if (!amt || amt <= 0) {
        alert('Montant invalide')
        return
      }

      let response
      if (hasDestinataire.value) {
        if (!destinataire.value) {
          alert('Numéro de compte destinataire requis')
          return
        }
        response = await bankStore.createPayment(bankStore.currentAccount._id, destinataire.value, amt)
      } else {
        response = await bankStore.createWithdraw(bankStore.currentAccount._id, amt)
      }

      if (response && response.error === 0) {
        successMessage.value = `L'opération est validée avec le n° : ${response.data.uuid}. Vous pouvez la retrouver dans l'historique.`
        setTimeout(() => {
          successMessage.value = ''
        }, 5000)
      } else if (response) {
        alert(response.data)
      }
    }

    return {
      amount,
      hasDestinataire,
      destinataire,
      successMessage,
      valider
    }
  }
}
</script>