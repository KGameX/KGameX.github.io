<template>
  <div>
    <h1>Débit/Virement</h1>
    <p>Effectuer des opérations.</p>
  </div>
</template>

<script>
export default {
  name: 'BankOperation'
}
</script>