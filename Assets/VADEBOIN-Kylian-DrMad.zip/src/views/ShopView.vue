<template>
    <div>
        <NavBar :titles="titles" @menu-clicked="goTo($event)"></NavBar>
        <h1>Boutique</h1>
        <router-view name="shopmain"></router-view>
    </div>
</template>

<script setup>
/* ***************************
  IMPORTS
 *************************** */
import NavBar from "@/components/NavBar.vue";
import {computed} from "vue";
import {useShopStore} from "@/stores/shop.js";
import { useRouter } from 'vue-router'

/* ***************************
  STATE
 *************************** */
const router = useRouter()
const shopStore = useShopStore()
const titles = computed(() => [
  {text: shopStore.shopUser ? 'Logout' : 'Login', color: 'green'},
  {text:'Virus', color: 'blue'},
  {text:'Commandes', color: 'red'},
])

/* ***************************
  FUNCTIONS
 *************************** */
function goTo(index) {
  if (index === 0) {
    if (shopStore.shopUser) {
      // Logout
      shopStore.shopUser = null
      router.push('/shop/login')
    } else {
      router.push('/shop/login')
    }
  }
  else if (index === 1) {
    router.push('/shop/buy')
  }
  else if (index === 2) {
    router.push('/shop/orders')
  }
}
</script>