<template>
    <div>
        <NavBar :links="links"></NavBar>
        <h1>Boutique</h1>
        <router-view name="shopmain"></router-view>
    </div>
</template>

<script setup>
/* ***************************
  IMPORTS
 *************************** */
import NavBar from "@/components/NavBar.vue";
import {computed} from "vue";
import {useShopStore} from "@/stores/shop.js";
import { useRouter } from 'vue-router'

/* ***************************
  STATE
 *************************** */
const router = useRouter()
const shopStore = useShopStore()
const links = computed(() => [
  { label : shopStore.shopUser ? 'Logout' : 'Login', to : '/shop/login'},
  { label :'Virus', to : '/shop/buy'},
  { label :'Commandes', to : '/shop/orders'},
])

/* ***************************
  FUNCTIONS
 *************************** */
</script>