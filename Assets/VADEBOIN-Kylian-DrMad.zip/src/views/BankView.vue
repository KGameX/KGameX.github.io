<template>
  <div class="bank-view">
    <NavBar :links="navItems" />
    <div class="content">
      <VerticalMenu :items="menuItems">
        <template #menu-title="{ label }">
          <strong><u>{{ label }}</u></strong>
        </template>
      </VerticalMenu>
      <router-view name="bankmain" v-slot="{ Component }">
        <component :is="Component" v-slot:account-amount="{ amount }">
          <input
            type="text"
            :value="amount + ' €'"
            readonly
            :class="{ negative: amount < 0, positive: amount >= 0 }"
          />
        </component>
      </router-view>
    </div>
  </div>
</template>

<script>
import NavBar from '@/components/NavBar.vue'
import VerticalMenu from '@/components/VerticalMenu.vue'
import { useBankStore } from '@/stores/bank'
import { computed } from 'vue'

export default {
  name: 'BankView',
  components: {
    NavBar,
    VerticalMenu
  },
  setup() {
    const bankStore = useBankStore()
    const navItems = computed(() => [
      {
        label: bankStore.currentAccount ? "Déconnexion" : "Mon compte",
        to: bankStore.currentAccount ? "/bank/logout" : "/bank/account"
      }
    ])
    const menuItems = computed(() => [
      { type: "title", label: "Opérations" },
      { type: "link", label: "Solde", to: "/bank/amount", disabled: !bankStore.currentAccount },
      { type: "link", label: "Débit/Virement", to: "/bank/operation", disabled: !bankStore.currentAccount },
      { type: "title", label: "États" },
      { type: "link", label: "Historique", to: "/bank/history", disabled: !bankStore.currentAccount }
    ])
    return {
      navItems,
      menuItems
    }
  }
}
</script>

<style scoped>
.bank-view {
  display: flex;
  flex-direction: column;
  height: 100vh;
}

.content {
  display: flex;
  flex: 1;
}

.negative {
  color: red;
}

.positive {
  color: green;
}
</style>