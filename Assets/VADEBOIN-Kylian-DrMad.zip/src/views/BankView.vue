<template>
  <div class="bank-view">
    <NavBar :items="navItems" />
    <div class="content">
      <VerticalMenu :items="menuItems">
        <template #menu-title="{ label }">
          <strong><u>{{ label }}</u></strong>
        </template>
      </VerticalMenu>
      <router-view name="bankmain" />
    </div>
  </div>
</template>

<script>
import NavBar from '@/components/NavBar.vue'
import VerticalMenu from '@/components/VerticalMenu.vue'

export default {
  name: 'BankView',
  components: {
    NavBar,
    VerticalMenu
  },
  data() {
    return {
      navItems: [{ label: "Mon compte", to: "/bank/account" }],
      menuItems: [
        { type: "title", label: "Opérations" },
        { type: "link", label: "Solde", to: "/bank/amount" },
        { type: "link", label: "Débit/Virement", to: "/bank/operation" },
        { type: "title", label: "États" },
        { type: "link", label: "Historique", to: "/bank/history" }
      ]
    }
  }
}
</script>

<style scoped>
.bank-view {
  display: flex;
  flex-direction: column;
  height: 100vh;
}

.content {
  display: flex;
  flex: 1;
}
</style>