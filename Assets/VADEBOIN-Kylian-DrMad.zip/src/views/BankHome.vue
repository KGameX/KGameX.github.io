<template>
  <div>
    <h1>Accueil Banque</h1>
    <p>Bienvenue sur votre espace bancaire.</p>
  </div>
</template>

<script>
export default {
  name: 'BankHome'
}
</script>