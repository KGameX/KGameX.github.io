<template>
  <div>
    <h1>Bienvenue à la banque</h1>
  </div>
</template>

<script>
export default {
  name: 'BankHome'
}
</script>