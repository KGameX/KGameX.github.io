<template>
  <div>
    <h1>
      <slot>Opérations passées</slot>
    </h1>

    <div>
      <label>
        <input type="checkbox" v-model="filterByPeriod" />
        Filtrer par période
      </label>
    </div>

    <div v-if="filterByPeriod" class="filter-fields">
      <label>
        Du:
        <input type="date" v-model="startDate" @change="validateDates" />
      </label>
      <label>
        Au:
        <input type="date" v-model="endDate" @change="validateDates" />
      </label>
    </div>

    <DataTable
      :items="filteredTransactions"
      :headers="headers"
      :item-check="true"
      :item-button="true"
      :table-button="true"
      @item-clicked="showItemDialog"
      @table-clicked="showTableDialog"
    >
      <template #item-button>Détails</template>
      <template #table-button>Voir</template>
    </DataTable>

    <!-- Dialog for item details -->
    <div v-if="showDialog" class="dialog-overlay" @click="closeDialog">
      <div class="dialog" @click.stop>
        <p>UUID de la transaction: {{ selectedUuid }}</p>
        <button @click="closeDialog">Fermer</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import { useBankStore } from '@/stores/bank'
import DataTable from '@/components/DataTable.vue'

const bankStore = useBankStore()

const filterByPeriod = ref(false)
const startDate = ref('')
const endDate = ref('')
const showDialog = ref(false)
const selectedUuid = ref('')

const headers = [
  { name: 'amount', label: 'Montant' },
  { name: 'date', label: 'Date' },
  { name: 'type', label: 'Type' }
]

const transactions = computed(() => {
  if (!bankStore.transactions) return []
  return bankStore.transactions.map(t => ({
    ...t,
    date: new Date(t.date.$date).toLocaleDateString(),
    type: t.amount < 0 ? 'S' : 'D'
  })).sort((a, b) => new Date(b.date.$date) - new Date(a.date.$date))
})

const filteredTransactions = computed(() => {
  if (!filterByPeriod.value) return transactions.value

  let filtered = transactions.value

  if (startDate.value) {
    const start = new Date(startDate.value)
    filtered = filtered.filter(t => new Date(t.date.$date) >= start)
  }

  if (endDate.value) {
    const end = new Date(endDate.value)
    filtered = filtered.filter(t => new Date(t.date.$date) <= end)
  }

  return filtered
})

const validateDates = () => {
  if (startDate.value && endDate.value) {
    const start = new Date(startDate.value)
    const end = new Date(endDate.value)
    if (start > end) {
      if (startDate.value && endDate.value && start > end) {
        endDate.value = ''
      }
    }
  }
}

const showItemDialog = (item) => {
  selectedUuid.value = item.uuid
  showDialog.value = true
}

const showTableDialog = (selectedItems) => {
  const uuids = selectedItems.map(item => item.uuid).join(', ')
  selectedUuid.value = uuids
  showDialog.value = true
}

const closeDialog = () => {
  showDialog.value = false
  selectedUuid.value = ''
}

onMounted(() => {
  if (bankStore.currentAccount) {
    bankStore.getTransactions(bankStore.currentAccount._id)
  }
})

watch(() => bankStore.currentAccount, (newAccount) => {
  if (newAccount) {
    bankStore.getTransactions(newAccount._id)
  }
})
</script>

<style scoped>
.filter-fields {
  margin: 10px 0;
}

.filter-fields label {
  margin-right: 20px;
}

.dialog-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
}

.dialog {
  background: white;
  padding: 20px;
  border-radius: 5px;
  max-width: 500px;
  width: 90%;
}

.dialog button {
  margin-top: 10px;
}
</style>