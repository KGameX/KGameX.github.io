<template>
  <div>
    <h1>Historique</h1>
    <p>Vos transactions passées.</p>
  </div>
</template>

<script>
export default {
  name: 'BankHistory'
}
</script>