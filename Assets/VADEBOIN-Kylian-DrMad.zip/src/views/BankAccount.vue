<template>
  <div>
    <h1>Mon Compte</h1>
    <p>Détails de votre compte bancaire.</p>
  </div>
</template>

<script>
export default {
  name: 'BankAccount'
}
</script>