<template>
  <div>
    <h1>Mon Compte</h1>
    <form @submit.prevent="validateAccount">
      <label for="accountNumber">Numéro de compte :</label>
      <input
        id="accountNumber"
        v-model="accountNumber"
        type="text"
        required
      />
      <button type="submit">Valider</button>
    </form>
    <p v-if="errorMessage" class="error">{{ errorMessage }}</p>
  </div>
</template>

<script>
import { useBankStore } from '@/stores/bank'
import { useRouter } from 'vue-router'

export default {
  name: 'BankAccount',
  data() {
    return {
      accountNumber: '',
      errorMessage: ''
    }
  },
  setup() {
    const bankStore = useBankStore()
    const router = useRouter()
    return { bankStore, router }
  },
  methods: {
    async validateAccount() {
      this.errorMessage = ''
      await this.bankStore.getAccount(this.accountNumber)
      if (this.bankStore.currentAccount) {
        // Compte valide, aller à la page solde
        this.router.push('/bank/amount')
      } else {
        this.errorMessage = 'Numéro de compte invalide'
      }
    }
  }
}
</script>

<style scoped>
.error {
  color: red;
}
</style>