<template>
  <div>
    <h1>Mes Commandes</h1>
    <div v-if="orders.length === 0">
      <p>Aucune commande trouvée.</p>
    </div>
    <div v-else>
      <div v-for="order in orders" :key="order.uuid" class="order-item">
        <p><strong>Montant:</strong> {{ order.total }} €</p>
        <p><strong>Statut:</strong> {{ order.status }}</p>
        <div v-if="order.status === 'waiting_payment'">
          <button @click="payOrder(order.uuid)">Payer</button>
          <button @click="cancelOrder(order.uuid)">Annuler</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { useShopStore } from '@/stores/shop'
import { onMounted, watch } from 'vue'
import { useRouter, useRoute } from 'vue-router'

export default {
  name: 'ShopOrders',
  setup() {
    const shopStore = useShopStore()
    const router = useRouter()
    const route = useRoute()

    const orders = shopStore.shopUser?.orders || []

    const loadOrders = async () => {
      await shopStore.loadOrders()
    }

    onMounted(async () => {
      await loadOrders()
    })

    watch(() => route.query.refresh, async (newVal, oldVal) => {
      if (newVal !== oldVal) {
        await loadOrders()
      }
    })

    const payOrder = (orderUuid) => {
      router.push(`/shop/pay/${orderUuid}`)
    }

    const cancelOrder = async (orderUuid) => {
      await shopStore.cancelOrder(orderUuid)
      router.push({ name: 'orders' })
    }

    return {
      orders,
      payOrder,
      cancelOrder
    }
  }
}
</script>

<style scoped>
.order-item {
  border: 1px solid #ccc;
  padding: 10px;
  margin: 10px 0;
}
</style>