import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  {
    path: '/shop',
    component: () => import('@/views/ShopView.vue'),
    children: [
      {
        path: 'home',
        name: 'home',
        components: {
          shopmain: () => import('@/views/ShopHome.vue')
        },
        alias: '/shop'
      },
      {
        path: 'login',
        name: 'login',
        components: {
          shopmain: () => import('@/views/ShopLoginView.vue')
        },
      },
      {
        path: 'buy',
        name: 'buy',
        components: {
          shopmain: () => import('@/views/ShopBuy.vue')
        },
      },
      {
        path: 'pay/:orderUuid',
        name: 'pay',
        components: {
          shopmain: () => import('@/views/ShopPay.vue')
        },
        props: true
      },
      {
        path: 'orders',
        name: 'orders',
        components: {
          shopmain: () => import('@/views/ShopOrders.vue')
        },
      }
    ]
  },
  {
    path: '/bank',
    component: () => import('@/views/BankView.vue'),
    children: [
      {
        path: 'home',
        components: {
          bankmain: () => import('@/views/BankHome.vue')
        },
        alias: '/bank'
      },
      {
        path: 'account',
        components: {
          bankmain: () => import('@/views/BankAccount.vue')
        }
      },
      {
        path: 'amount',
        components: {
          bankmain: () => import('@/views/BankAmount.vue')
        }
      },
      {
        path: 'operation',
        components: {
          bankmain: () => import('@/views/BankOperation.vue')
        }
      },
      {
        path: 'history',
        components: {
          bankmain: () => import('@/views/BankHistory.vue')
        }
      },
      {
        path: 'logout',
        components: {
          bankmain: () => import('@/views/BankLogout.vue')
        }
      }
    ]
  }
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: routes,
})

export default router