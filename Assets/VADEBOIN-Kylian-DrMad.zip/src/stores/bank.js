import { ref} from 'vue'
import { defineStore } from 'pinia'

import BankAccountService from '@/services/bankaccount.service'

export const useBankStore = defineStore('bank', () => {

  const currentAccount = ref(null)
  const transactions = ref([])

  async function getAccount(number) {
    console.log('get account');
    let response = await BankAccountService.getAccount(number)
    if (response.error === 0) {
      currentAccount.value = response.data
    } else {
      console.log(response.data)
      currentAccount.value = null
    }
  }

  async function getTransactions(idAccount) {
    console.log('get transactions');
    let response = await BankAccountService.getTransactions(idAccount)
    if (response.error === 0) {
      transactions.value = response.data
    } else {
      console.log(response.data)
      transactions.value = []
    }
  }

  async function createWithdraw(idAccount, amount) {
    console.log('create withdraw');
    let response = await BankAccountService.createWithdraw(idAccount, amount)
    if (response.error === 0) {
      // Mettre à jour le solde du compte courant
      if (currentAccount.value && currentAccount.value._id === idAccount) {
        currentAccount.value.amount = response.data.amount
      }
      // Ajouter la transaction au tableau (optionnel, peut être rechargé)
      // Pour simplifier, on peut recharger les transactions
      await getTransactions(idAccount)
    } else {
      console.log(response.data)
    }
  }

  async function createPayment(idAccount, destNumber, amount) {
    console.log('create payment');
    let response = await BankAccountService.createPayment(idAccount, destNumber, amount)
    if (response.error === 0) {
      // Mettre à jour le solde du compte courant
      if (currentAccount.value && currentAccount.value._id === idAccount) {
        currentAccount.value.amount = response.data.amount
      }
      // Ajouter les transactions au tableau (optionnel)
      await getTransactions(idAccount)
    } else {
      console.log(response.data)
    }
  }

  return { currentAccount, transactions, getAccount, getTransactions, createWithdraw, createPayment }
})
