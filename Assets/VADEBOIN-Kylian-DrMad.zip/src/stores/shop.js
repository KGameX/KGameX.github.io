import { ref } from 'vue'
import { defineStore } from 'pinia'

import ShopService from '@/services/shop.service'

export const useShopStore = defineStore('shop', () => {

  const viruses = ref([])
  const shopUser = ref(null)
  const basket = ref({ items: [] })

  async function shopLogin(data) {
    console.log('login');
    let response = await ShopService.shopLogin(data)
    if (response.error === 0) {
      shopUser.value = response.data
      await loadBasket()
    }
    else {
      console.log(response.data)
    }
  }

  async function getAllViruses() {
    console.log('récupération des viruses');
    let response = await ShopService.getAllViruses()
    if (response.error === 0) {
      viruses.value = response.data
    }
    else {
      console.log(response.data)
    }
  }

  async function loadBasket() {
    if (shopUser.value) {
      let response = await ShopService.getBasket(shopUser.value._id)
      if (response.error === 0) {
        basket.value = response.data
      } else {
        console.log(response.data)
      }
    }
  }

  async function addToBasket(itemId, amount) {
    if (!shopUser.value) return
    let itemIndex = basket.value.items.findIndex(item => item.item === itemId)
    if (itemIndex >= 0) {
      basket.value.items[itemIndex].amount += amount
    } else {
      basket.value.items.push({ item: itemId, amount: amount })
    }
    await updateBasket()
  }

  async function removeFromBasket(itemId) {
    if (!shopUser.value) return
    basket.value.items = basket.value.items.filter(item => item.item !== itemId)
    await updateBasket()
  }

  async function clearBasket() {
    if (!shopUser.value) return
    basket.value.items = []
    await updateBasket()
  }

  async function updateBasket() {
    if (!shopUser.value) return
    let response = await ShopService.updateBasket(shopUser.value._id, basket.value)
    if (response.error !== 0) {
      console.log(response.data)
    }
  }

  async function loadOrders() {
    if (shopUser.value) {
      let response = await ShopService.getUserOrders(shopUser.value._id)
      if (response.error === 0) {
        shopUser.value.orders = response.data
      } else {
        console.log(response.data)
      }
    }
  }

  async function cancelOrder(orderUuid) {
    if (!shopUser.value) return
    let response = await ShopService.cancelOrder(orderUuid, shopUser.value._id)
    if (response.error === 0) {
      // Mettre à jour le statut dans shopUser.value.orders
      let order = shopUser.value.orders.find(o => o.uuid === orderUuid)
      if (order) order.status = 'cancelled'
    } else {
      console.log(response.data)
    }
  }

  return { viruses, shopUser, basket, shopLogin, getAllViruses, loadBasket, addToBasket, removeFromBasket, clearBasket, loadOrders, cancelOrder }
})
