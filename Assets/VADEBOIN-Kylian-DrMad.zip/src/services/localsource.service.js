import { items, shopusers, bankaccounts, transactions } from '@/datasource/data.js'
import { v4 as uuidv4 } from 'uuid'
import bcryptjs from 'bcryptjs'
import router from '@/router'
/* Les fonctions ci-dessous doivent mimer ce que renvoie l'API en fonction des requêtes possibles.

  Dans certains cas, ces fonctions vont avoir des paramètres afin de filtrer les données qui se trouvent dans data.js
  Il est fortement conseillé que ces paramètres soient les mêmes que ceux qu'il faudrait envoyer à l'API.

  IMPORTANT : toutes les requêtes à l'API DOIVENT renvoyer un objet JSON au format {error: ..., status: ..., data: ...}
  Cela implique que toutes les foncitons ci-dessous renvoient un objet selon ce format.
 */

/**
 * Si le login et le mot de passe sont fournis, que le login correspond à un utilisateur existant,
 * shopLogin() renvoie un objet contenant uniquement l'id, le nom, le login, l'email
 * et un identifiant de session sous forme d'un uuid. Sinon, un texte d'erreur est renvoyé.
 * NB: pas de test du mot de passe dans cet exemple.
 * @param data
 * @returns {{error: number, status: number, data: string}|{error: number, status: number, data: {_id: string | *, name: string | *, login: string | *, email: string | *, session}}}
 */
function shopLogin(data) {
  if ((!data.login) || (!data.password)) return { error: 1, status: 404, data: 'aucun login/pass fourni' }
  // pour simplifier : test uniquement le login
  let user = shopusers.find(e => e.login === data.login)
  if (!user) return { error: 1, status: 404, data: 'login/pass incorrect' }
  // générer un uuid de session pour l'utilisateur si non existant
  if (bcryptjs.compareSync(data.password, user.password)) {
    if (!user.session) {
      user.session = uuidv4()
    }
    // retourne uniquement les champs nécessaires
    let u = {
      _id: user._id,
      name: user.name,
      login: user.login,
      email: user.email,
      session: user.session
    }
    router.push('/shop/buy')
    return { error: 0, status: 200, data: u }
  } else {
    return { error: 1, status: 404, data: 'login/pass incorrect' }
  }
}

/**
 * getAllViruses() renvoie un tableau d'items dont le format est le même que celui stockée en source locale (donc aussi en BdD côté API)
 * @returns {{error: number, data}}
 */
function getAllViruses() {
  return { error: 0, data: items }
}

/**
 * Si un n° est fourni et qu'il correspond à un compte existant, getAccountAmount() renvoie uniquement le solde
 * du compte, sinon un texte d'erreur.
 * @param number
 * @returns {{error: number, status: number, data: string}|{error: number, status: number, data: number | *}}
 */
function getAccountAmount(number) {
  if (!number) return { error: 1, status: 404, data: 'aucun numéro de compte bancaire fourni' }
  let account = bankaccounts.find(a => a.number === number)
  if (!account) return { error: 1, status: 404, data: 'numéro de compte bancaire incorrect' }
  return { error: 0, status: 200, data: account.amount }
}

/**
 * Si un n° est fourni et qu'il correspond à un compte existant, getAccountTransactions() renvoie uniquement le solde
 * du compte, sinon un texte d'erreur.
 * @param number
 * @returns {{error: number, status: number, data: ({_id: string, amount: number, account: string, date: {$date: string}, uuid: string}|{_id: string, amount: number, account: string, date: {$date: string}, uuid: string}|{_id: string, amount: number, account: string, date: {$date: string}, uuid: string})[]}|{error: number, status: number, data: string}}
 */
function getAccountTransactions(number) {
  if (!number) return { error: 1, status: 404, data: 'aucun numéro de compte bancaire fourni' }
  let account = bankaccounts.find(a => a.number === number)
  if (!account) return { error: 1, status: 404, data: 'numéro de compte bancaire incorrect' }
  // récupérer les transaction grâce à l'_id du compte
  let trans = transactions.filter(t => t.account === account._id)
  return { error: 0, status: 200, data: trans }
}

/**
 * Met à jour le panier (basket) d'un utilisateur dans la source locale.
 * @param userId
 * @param basket
 * @returns {{error: number, status: number, data: string}}
 */
function updateBasket(userId, basket) {
  if (!userId) return { error: 1, status: 404, data: 'aucun userId fourni' }
  let user = shopusers.find(u => u._id === userId)
  if (!user) return { error: 1, status: 404, data: 'utilisateur non trouvé' }
  user.basket = basket
  return { error: 0, status: 200, data: 'panier mis à jour' }
}

/**
 * Récupère le panier (basket) d'un utilisateur depuis la source locale.
 * @param userId
 * @returns {{error: number, status: number, data: *}}
 */
function getBasket(userId) {
  if (!userId) return { error: 1, status: 404, data: 'aucun userId fourni' }
  let user = shopusers.find(u => u._id === userId)
  if (!user) return { error: 1, status: 404, data: 'utilisateur non trouvé' }
  if (user.basket == null) user.basket = { items: [] }
  let basket = JSON.parse(JSON.stringify(user.basket))
  return { error: 0, status: 200, data: basket }
}

/**
 * Crée une commande à partir du panier d'un utilisateur.
 * @param userId
 * @param basket
 * @returns {{error: number, status: number, data: {uuid: string}}}
 */
function orderBasket(userId, basket) {
  if (!userId) return { error: 1, status: 404, data: 'aucun userId fourni' }
  let user = shopusers.find(u => u._id === userId)
  if (!user) return { error: 1, status: 404, data: 'utilisateur non trouvé' }
  if (!basket || !basket.items) return { error: 1, status: 400, data: 'panier invalide' }

  let orderItems = []
  let total = 0

  for (let basketItem of basket.items) {
    let item = items.find(i => i._id === basketItem.item)
    if (!item) continue // skip if item not found

    // Calculate price with promotion
    let price = item.price
    if (item.promotion && item.promotion.length > 0) {
      // Find the best applicable promotion (highest discount where amount >= threshold)
      let applicablePromotions = item.promotion.filter(p => basketItem.amount >= p.amount)
      if (applicablePromotions.length > 0) {
        let bestPromo = applicablePromotions.reduce((prev, curr) => prev.discount > curr.discount ? prev : curr)
        price = price * (1 - bestPromo.discount / 100)
      }
    }
    let itemTotal = price * basketItem.amount
    total += itemTotal

    orderItems.push({
      item: {
        name: item.name,
        description: item.description,
        price: item.price,
        promotion: item.promotion,
        object: item.object
      },
      amount: basketItem.amount
    })
  }

  let uuid = uuidv4()
  let order = {
    items: orderItems,
    date: new Date(),
    total: total,
    status: 'waiting_payment',
    uuid: uuid
  }

  if (!user.orders) user.orders = []
  user.orders.push(order)

  return { error: 0, status: 201, data: { uuid: uuid } }
}

/**
 * getOrder() prend en paramètre l'uuid d'une commande et l'id d'un utilisateur et renvoie les informations de la commande.
 * @param uuid
 * @param userId
 * @returns {{error: number, status: number, data: *}}
 */
function getOrder(uuid, userId) {
  let user = shopusers.find(u => u._id === userId)
  if (!user) return { error: 1, status: 404, data: 'Utilisateur non trouvé' }
  let order = user.orders.find(o => o.uuid === uuid)
  if (!order) return { error: 1, status: 404, data: 'Commande non trouvée' }
  // retourner un clone
  return { error: 0, status: 200, data: JSON.parse(JSON.stringify(order)) }
}

/**
 * payOrder() prend en paramètre l'uuid d'une commande et l'id d'un utilisateur et modifie le statut de la commande à "finalized".
 * @param data {uuid, userId, transactionUuid}
 * @returns {{error: number, status: number, data: string}}
 */
function payOrder(data) {
  let { uuid, userId, transactionUuid } = data
  let user = shopusers.find(u => u._id === userId)
  if (!user) return { error: 1, status: 404, data: 'Utilisateur non trouvé' }
  let order = user.orders.find(o => o.uuid === uuid)
  if (!order) return { error: 1, status: 404, data: 'Commande non trouvée' }
  // Vérifier la transaction bancaire
  let transaction = transactions.find(t => t.uuid === transactionUuid)
  if (!transaction) return { error: 1, status: 404, data: 'Transaction bancaire non trouvée' }
  order.status = 'finalized'
  return { error: 0, status: 200, data: 'Commande payée' }
}

/**
 * getUserOrders() prend en paramètre l'id d'un utilisateur et renvoie toutes ses commandes ou un tableau vide.
 * @param userId
 * @returns {{error: number, status: number, data: *[]}}
 */
function getUserOrders(userId) {
  if (!userId) return { error: 1, status: 404, data: 'aucun userId fourni' }
  let user = shopusers.find(u => u._id === userId)
  if (!user) return { error: 1, status: 404, data: 'utilisateur non trouvé' }
  if (!user.orders) user.orders = []
  // retourner un clone
  return { error: 0, status: 200, data: JSON.parse(JSON.stringify(user.orders)) }
}

/**
 * cancelOrder() prend en paramètre l'uuid d'une commande et l'id d'un utilisateur et modifie le statut de la commande à "cancelled".
 * @param uuid
 * @param userId
 * @returns {{error: number, status: number, data: string}}
 */
function cancelOrder(uuid, userId) {
  let user = shopusers.find(u => u._id === userId)
  if (!user) return { error: 1, status: 404, data: 'Utilisateur non trouvé' }
  let order = user.orders.find(o => o.uuid === uuid)
  if (!order) return { error: 1, status: 404, data: 'Commande non trouvée' }
  order.status = 'cancelled'
  return { error: 0, status: 200, data: 'Commande annulée' }
}

/**
 * getAccount() permet de récupérer toutes les informations d'un compte si data.number correspond à un numéro valide.
 * @param data {number}
 * @returns {{error: number, status: number, data: object|string}}
 */
function getAccount(data) {
  if (!data.number) return { error: 1, status: 404, data: 'aucun numéro de compte fourni' }
  let account = bankaccounts.find(a => a.number === data.number)
  if (!account) return { error: 1, status: 404, data: 'numéro de compte invalide' }
  return { error: 0, status: 200, data: JSON.parse(JSON.stringify(account)) }
}

/**
 * getTransactions() permet de récupérer toutes les transactions liées à un id de compte.
 * @param data {idAccount}
 * @returns {{error: number, status: number, data: array|string}}
 */
function getTransactions(data) {
  if (!data.idAccount) return { error: 1, status: 404, data: 'aucun id de compte fourni' }
  let trans = transactions.filter(t => t.account === data.idAccount)
  if (trans.length === 0) return { error: 1, status: 404, data: 'aucune transaction pour ce compte' }
  return { error: 0, status: 200, data: JSON.parse(JSON.stringify(trans)) }
}

/**
 * createWithdraw() permet de créer un objet transaction avec un montant négatif et de débiter le compte.
 * @param data {idAccount, amount}
 * @returns {{error: number, status: number, data: object|string}}
 */
function createWithdraw(data) {
  if (!data.idAccount) return { error: 1, status: 404, data: 'aucun id de compte fourni' }
  let account = bankaccounts.find(a => a._id === data.idAccount)
  if (!account) return { error: 1, status: 404, data: 'id de compte invalide' }
  if (!data.amount || data.amount <= 0) return { error: 1, status: 400, data: 'montant invalide' }
  // Créer la transaction
  let uuid = uuidv4()
  let transaction = {
    _id: uuidv4(), // générer un _id aussi ?
    amount: -data.amount,
    account: data.idAccount,
    date: { $date: new Date().toISOString() },
    uuid: uuid
  }
  transactions.push(transaction)
  // Débiter le compte
  account.amount -= data.amount
  return { error: 0, status: 201, data: { uuid: uuid, amount: account.amount } }
}

/**
 * createPayment() permet de créer deux transactions pour un paiement.
 * @param data {idAccount, destNumber, amount}
 * @returns {{error: number, status: number, data: object|string}}
 */
function createPayment(data) {
  if (!data.idAccount) return { error: 1, status: 404, data: 'aucun id de compte fourni' }
  let sourceAccount = bankaccounts.find(a => a._id === data.idAccount)
  if (!sourceAccount) return { error: 1, status: 404, data: 'id de compte invalide' }
  if (!data.destNumber) return { error: 1, status: 404, data: 'aucun numéro de compte destinataire fourni' }
  let destAccount = bankaccounts.find(a => a.number === data.destNumber)
  if (!destAccount) return { error: 1, status: 404, data: 'compte destinataire inexistant' }
  if (!data.amount || data.amount <= 0) return { error: 1, status: 400, data: 'montant invalide' }
  // Générer date commune
  let date = { $date: new Date().toISOString() }
  // Transaction débit
  let debitUuid = uuidv4()
  let debitTransaction = {
    _id: uuidv4(),
    amount: -data.amount,
    account: data.idAccount,
    destination: destAccount._id,
    date: date,
    uuid: debitUuid
  }
  transactions.push(debitTransaction)
  // Transaction crédit
  let creditUuid = uuidv4()
  let creditTransaction = {
    _id: uuidv4(),
    amount: data.amount,
    account: destAccount._id,
    date: date,
    uuid: creditUuid
  }
  transactions.push(creditTransaction)
  // Débiter le compte source
  sourceAccount.amount -= data.amount
  // Créditer le compte dest
  destAccount.amount += data.amount
  return { error: 0, status: 201, data: { uuid: debitUuid, amount: sourceAccount.amount } }
}

export default {
  shopLogin,
  getAllViruses,
  getAccountAmount,
  getAccountTransactions,
  updateBasket,
  getBasket,
  orderBasket,
  getOrder,
  payOrder,
  getUserOrders,
  cancelOrder,
  getAccount,
  getTransactions,
  createWithdraw,
  createPayment,
}