import LocalSource from "@/services/localsource.service.js";

async function shopLoginFromLocalSource(data) {
  // récupération auprès de la source locale
  return LocalSource.shopLogin(data)
}
/*
async function shopLoginFromAPI(data) {
  // a écrire quand l'API est fonctionnelle
  return {}
}
 */

async function getAllVirusesFromLocalSource() {
  // récupération auprès de la source locale
  return LocalSource.getAllViruses()
}

/*
async function getAllVirusesFromAPI() {
  // a écrire quand l'API est fonctionnelle
  return {}
}
*/

async function updateBasketFromLocalSource(userId, basket) {
  // mise à jour auprès de la source locale
  return LocalSource.updateBasket(userId, basket)
}

/*
async function updateBasketFromAPI(userId, basket) {
  // a écrire quand l'API est fonctionnelle
  return {}
}
*/

async function getBasketFromLocalSource(userId) {
  // récupération auprès de la source locale
  return LocalSource.getBasket(userId)
}

/*
async function getBasketFromAPI(userId) {
  // a écrire quand l'API est fonctionnelle
  return {}
}
*/

async function orderBasketFromLocalSource(userId, basket) {
  // création de commande auprès de la source locale
  return LocalSource.orderBasket(userId, basket)
}

/*
async function orderBasketFromAPI(userId, basket) {
  // a écrire quand l'API est fonctionnelle
  return {}
}
*/

async function shopLogin(data) {
  let response = null;
  try {
    // changer la méthode appelée quand cette fonctionnalité l'API est prête
    response = await shopLoginFromLocalSource(data)
  }
    // NB: le catch n'aura lieu que pour des requête vers l'API, s'il y a une erreur réseau
  catch(err) {
    response = {error: 1, status: 404, data: 'erreur réseau, impossible de se loguer'  }
  }
  return response
}


async function getAllViruses() {
  let response = null;
  try {
    // changer la méthode appelée quand cette fonctionnalité l'API est prête
    response = await getAllVirusesFromLocalSource()
  }
  // NB: le catch n'aura lieu que pour des requête vers l'API, s'il y a une erreur réseau
  catch(err) {
    response = {error: 1, status: 404, data: 'erreur réseau, impossible de récupérer la liste des viruses'  }
  }
  return response
}

async function updateBasket(userId, basket) {
  let response = null;
  try {
    // changer la méthode appelée quand cette fonctionnalité l'API est prête
    response = await updateBasketFromLocalSource(userId, basket)
  }
  // NB: le catch n'aura lieu que pour des requête vers l'API, s'il y a une erreur réseau
  catch(err) {
    response = {error: 1, status: 404, data: 'erreur réseau, impossible de mettre à jour le panier'  }
  }
  return response
}

async function getBasket(userId) {
  let response = null;
  try {
    // changer la méthode appelée quand cette fonctionnalité l'API est prête
    response = await getBasketFromLocalSource(userId)
  }
  // NB: le catch n'aura lieu que pour des requête vers l'API, s'il y a une erreur réseau
  catch(err) {
    response = {error: 1, status: 404, data: 'erreur réseau, impossible de récupérer le panier'  }
  }
  return response
}

async function orderBasket(userId, basket) {
  let response = null;
  try {
    // changer la méthode appelée quand cette fonctionnalité l'API est prête
    response = await orderBasketFromLocalSource(userId, basket)
  }
  // NB: le catch n'aura lieu que pour des requête vers l'API, s'il y a une erreur réseau
  catch(err) {
    response = {error: 1, status: 404, data: 'erreur réseau, impossible de créer la commande'  }
  }
  return response
}

async function getOrder(uuid, userId) {
  let response = null;
  try {
    // changer la méthode appelée quand cette fonctionnalité l'API est prête
    response = await getOrderFromLocalSource(uuid, userId)
  }
  // NB: le catch n'aura lieu que pour des requête vers l'API, s'il y a une erreur réseau
  catch(err) {
    response = {error: 1, status: 404, data: 'erreur réseau, impossible de récupérer la commande'  }
  }
  return response
}

async function payOrder(data) {
  let response = null;
  try {
    // changer la méthode appelée quand cette fonctionnalité l'API est prête
    response = await payOrderFromLocalSource(data)
  }
  // NB: le catch n'aura lieu que pour des requête vers l'API, s'il y a une erreur réseau
  catch(err) {
    response = {error: 1, status: 404, data: 'erreur réseau, impossible de payer la commande'  }
  }
  return response
}

async function getUserOrders(userId) {
  let response = null;
  try {
    // changer la méthode appelée quand cette fonctionnalité l'API est prête
    response = await getUserOrdersFromLocalSource(userId)
  }
  // NB: le catch n'aura lieu que pour des requête vers l'API, s'il y a une erreur réseau
  catch(err) {
    response = {error: 1, status: 404, data: 'erreur réseau, impossible de récupérer les commandes'  }
  }
  return response
}

async function cancelOrder(uuid, userId) {
  let response = null;
  try {
    // changer la méthode appelée quand cette fonctionnalité l'API est prête
    response = await cancelOrderFromLocalSource(uuid, userId)
  }
  // NB: le catch n'aura lieu que pour des requête vers l'API, s'il y a une erreur réseau
  catch(err) {
    response = {error: 1, status: 404, data: 'erreur réseau, impossible d\'annuler la commande'  }
  }
  return response
}

async function getOrderFromLocalSource(uuid, userId) {
  // récupération auprès de la source locale
  return LocalSource.getOrder(uuid, userId)
}

/*
async function getOrderFromAPI(uuid, userId) {
  // a écrire quand l'API est fonctionnelle
  return {}
}
*/

async function payOrderFromLocalSource(data) {
  // mise à jour auprès de la source locale
  return LocalSource.payOrder(data)
}

/*
async function payOrderFromAPI(uuid, userId) {
  // a écrire quand l'API est fonctionnelle
  return {}
}
*/

async function getUserOrdersFromLocalSource(userId) {
  // récupération auprès de la source locale
  return LocalSource.getUserOrders(userId)
}

/*
async function getUserOrdersFromAPI(userId) {
  // a écrire quand l'API est fonctionnelle
  return {}
}
*/

async function cancelOrderFromLocalSource(uuid, userId) {
  // mise à jour auprès de la source locale
  return LocalSource.cancelOrder(uuid, userId)
}

/*
async function cancelOrderFromAPI(uuid, userId) {
  // a écrire quand l'API est fonctionnelle
  return {}
}
*/

export default {
  shopLogin,
  getAllViruses,
  updateBasket,
  getBasket,
  orderBasket,
  getOrder,
  payOrder,
  getUserOrders,
  cancelOrder
}