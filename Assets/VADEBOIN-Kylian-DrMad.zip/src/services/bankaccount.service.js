import LocalSource from "@/services/localsource.service.js";

async function getAccountAmountFromLocalSource(number) {
  // récupération auprès de la source locale
  return LocalSource.getAccountAmount(number)
}

async function getAccountTransactionsFromLocalSource(number) {
  // récupération auprès de la source locale
  return LocalSource.getAccountTransactions(number)
}

async function getAccountFromLocalSource(number) {
  // récupération auprès de la source locale
  return LocalSource.getAccount({ number })
}

async function getTransactionsFromLocalSource(idAccount) {
  // récupération auprès de la source locale
  return LocalSource.getTransactions({ idAccount })
}

async function createWithdrawFromLocalSource(data) {
  // récupération auprès de la source locale
  return LocalSource.createWithdraw(data)
}

async function createPaymentFromLocalSource(data) {
  // récupération auprès de la source locale
  return LocalSource.createPayment(data)
}

async function getAccountAmount(number) {
  let response = null;
  try {
    // changer la méthode appelée quand cette fonctionnalité l'API est prête
    response = await getAccountAmountFromLocalSource(number)
  }
    // NB: le catch n'aura lieu que pour des requête vers l'API, s'il y a une erreur réseau
  catch(err) {
    response = {error: 1, status: 404, data: 'erreur réseau, impossible de se loguer'  }
  }
  return response
}

async function getAccountTransactions(number) {
  let response = null;
  try {
    // changer la méthode appelée quand cette fonctionnalité l'API est prête
    response = await getAccountTransactionsFromLocalSource(number)
  }
    // NB: le catch n'aura lieu que pour des requête vers l'API, s'il y a une erreur réseau
  catch(err) {
    response = {error: 1, status: 404, data: 'erreur réseau, impossible de se loguer'  }
  }
  return response
}

async function getAccount(number) {
  let response = null;
  try {
    // changer la méthode appelée quand cette fonctionnalité l'API est prête
    response = await getAccountFromLocalSource(number)
  }
    // NB: le catch n'aura lieu que pour des requête vers l'API, s'il y a une erreur réseau
  catch(err) {
    response = {error: 1, status: 404, data: 'erreur réseau, impossible de se loguer'  }
  }
  return response
}

async function getTransactions(idAccount) {
  let response = null;
  try {
    // changer la méthode appelée quand cette fonctionnalité l'API est prête
    response = await getTransactionsFromLocalSource(idAccount)
  }
    // NB: le catch n'aura lieu que pour des requête vers l'API, s'il y a une erreur réseau
  catch(err) {
    response = {error: 1, status: 404, data: 'erreur réseau, impossible de se loguer'  }
  }
  return response
}

async function createWithdraw(idAccount, amount) {
  let response = null;
  try {
    // changer la méthode appelée quand cette fonctionnalité l'API est prête
    response = await createWithdrawFromLocalSource({ idAccount, amount })
  }
    // NB: le catch n'aura lieu que pour des requête vers l'API, s'il y a une erreur réseau
  catch(err) {
    response = {error: 1, status: 404, data: 'erreur réseau, impossible de se loguer'  }
  }
  return response
}

async function createPayment(idAccount, destNumber, amount) {
  let response = null;
  try {
    // changer la méthode appelée quand cette fonctionnalité l'API est prête
    response = await createPaymentFromLocalSource({ idAccount, destNumber, amount })
  }
    // NB: le catch n'aura lieu que pour des requête vers l'API, s'il y a une erreur réseau
  catch(err) {
    response = {error: 1, status: 404, data: 'erreur réseau, impossible de se loguer'  }
  }
  return response
}

export default {
  getAccountAmount,
  getAccountTransactions,
  getAccount,
  getTransactions,
  createWithdraw,
  createPayment,
}
