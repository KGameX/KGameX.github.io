<template>
  <div>
    <CheckedList :data="dataFormatted"
                 :fields="['name', 'price', 'promotionDisplay']"
                 item-check
                 :item-amount="true"
                 :item-button="{show: true, text:'Ajouter au panier'}"
                 :list-button="{show: true, text:'Ajouter sélection'}"
                 :checked="checked"
                 @checked-changed="changeSelection($event)"
                 @item-button-clicked="addToBasket($event)"
                 @list-button-clicked="addSelectedToBasket($event)"
    >
    </CheckedList>
  </div>
</template>

<script setup>
/* ***************************
  IMPORTS
 *************************** */
import CheckedList from "@/components/CheckedList.vue";
import { ref, computed } from "vue";
import { useShopStore } from "@/stores/shop.js";

/* ***************************
  STATE
 *************************** */
const shopStore = useShopStore();
const selected = ref([]);

/* ***************************
  COMPUTED
 *************************** */
const checked = computed(() => {
  return shopStore.viruses.map((_, index) => selected.value.includes(index));
});

const dataFormatted = computed(() => {
  return shopStore.viruses.map(virus => ({
    ...virus,
    promotionDisplay: virus.promotion.map(p => `${p.discount}% off for ${p.amount}+`).join(', ')
  }));
});

/* ***************************
  FUNCTIONS
 *************************** */
function changeSelection(idx) {
  const index = selected.value.indexOf(idx);
  if (index > -1) {
    selected.value.splice(index, 1);
  } else {
    selected.value.push(idx);
  }
}

function addToBasket({ index, amount }) {
  const virus = shopStore.viruses[index];
  shopStore.addToBasket(virus._id, amount);
}

function addSelectedToBasket(selectedItems) {
  selectedItems.forEach(({ index, amount }) => {
    const virus = shopStore.viruses[index];
    shopStore.addToBasket(virus._id, amount);
  });
  // Désélectionner les items
  selected.value = [];
}
</script>