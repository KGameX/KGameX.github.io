<template>
  <div class="vertical-menu">
    <div v-for="(item, index) in items" :key="index" class="menu-item">
      <div v-if="item.type === 'title'" class="menu-title">
        <slot name="menu-title" :label="item.label">{{ item.label }}</slot>
      </div>
      <span v-else-if="item.type === 'link'" @click="goTo(item.to)" class="menu-link">
        <slot name="menu-link" :label="item.label">
          <button :disabled="item.disabled">{{ item.label }}</button>
        </slot>
      </span>
    </div>
  </div>
</template>

<script setup>
/* ***************************
  IMPORTS
 *************************** */
import { useRouter } from 'vue-router'

/* ***************************
  PROPS
 *************************** */
defineProps({
  items: {
    type: Array,
    default: () => []
  }
})

/* ***************************
  COMPOSABLES
 *************************** */
const router = useRouter()

/* ***************************
  METHODS
 *************************** */
const goTo = (dest) => {
  router.push(dest)
}
</script>

<style scoped>
.vertical-menu {
  display: flex;
  flex-direction: column;
}

.menu-item {
  margin-bottom: 10px;
}

.menu-title {
  font-weight: bold;
  margin-bottom: 5px;
}

.menu-link {
  cursor: pointer;
}

.menu-link button {
  /* Style du bouton par défaut */
  background: none;
  border: none;
  cursor: pointer;
}
</style>