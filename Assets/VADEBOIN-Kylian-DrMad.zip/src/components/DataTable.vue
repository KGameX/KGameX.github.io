<template>
  <div class="data-table">
    <table class="table">
      <thead>
        <tr>
          <th v-if="itemCheck">select.</th>
          <th v-for="header in headers" :key="header.name">{{ header.label }}</th>
          <th v-if="itemButton">actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(item, index) in items" :key="index">
          <td v-if="itemCheck">
            <input type="checkbox" v-model="selectedItems" :value="item" />
          </td>
          <td v-for="header in headers" :key="header.name">{{ item[header.name] }}</td>
          <td v-if="itemButton">
            <button @click="handleItemClick(item)" class="btn btn-sm btn-primary">
              <slot name="item-button">Action</slot>
            </button>
          </td>
        </tr>
      </tbody>
    </table>
    <div v-if="tableButton" class="table-button-container">
      <button @click="handleTableClick" class="btn btn-primary">
        <slot name="table-button">Table Action</slot>
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const props = defineProps({
  items: {
    type: Array,
    default: () => []
  },
  headers: {
    type: Array,
    default: () => []
  },
  itemCheck: {
    type: Boolean,
    default: false
  },
  itemButton: {
    type: Boolean,
    default: false
  },
  tableButton: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['itemClicked', 'tableClicked'])

const selectedItems = ref([])

const handleItemClick = (item) => {
  emit('itemClicked', item)
}

const handleTableClick = () => {
  emit('tableClicked', selectedItems.value)
}
</script>

<style scoped>
.data-table {
  margin: 20px 0;
}

.table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 20px;
}

.table th,
.table td {
  border: 1px solid #ddd;
  padding: 8px;
  text-align: left;
}

.table th {
  background-color: #f2f2f2;
  font-weight: bold;
}

.table tr:nth-child(even) {
  background-color: #f9f9f9;
}

.table tr:hover {
  background-color: #f5f5f5;
}

.btn {
  padding: 6px 12px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
}

.btn-primary {
  background-color: #007bff;
  color: white;
}

.btn-primary:hover {
  background-color: #0056b3;
}

.btn-sm {
  padding: 4px 8px;
  font-size: 12px;
}

.table-button-container {
  text-align: center;
}
</style>