<template>
  <div>
    <h3>Panier</h3>
    <CheckedList :data="dataFormatted"
                 :fields="['name', 'amount', 'price']"
                 :item-button="{show: true, text:'Supprimer'}"
                 :list-button="{show: true, text:'Vider le panier'}"
                 @item-button-clicked="removeItem($event)"
                 @list-button-clicked="clearBasket"
    >
    </CheckedList>
    <button v-if="basket && basket.length > 0" @click="buy">Acheter</button>
  </div>
</template>

<script setup>
import { computed, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import CheckedList from '@/components/CheckedList.vue';
import { useShopStore } from '@/stores/shop.js';
import ShopService from '@/services/shop.service.js';

const shopStore = useShopStore();
const router = useRouter();

const basket = computed(() => shopStore.basket?.items || []);

const dataFormatted = computed(() => {
  return basket.value.map(bi => {
    const virus = shopStore.viruses.find(v => v._id === bi.item);
    return {
      name: virus ? virus.name : 'Unknown',
      amount: bi.amount,
      price: virus ? (virus.price * bi.amount).toFixed(2) + ' €' : 'N/A'
    };
  });
});

onMounted(() => {
  shopStore.loadBasket();
});

async function removeItem(event) {
  const index = event.index;
  const itemId = basket.value[index].item;
  await shopStore.removeFromBasket(itemId);
}

async function clearBasket() {
  await shopStore.clearBasket();
}

async function buy() {
  const response = await ShopService.orderBasket(shopStore.shopUser._id, shopStore.basket);
  if (response.error === 0) {
    await shopStore.clearBasket();
    router.push('/shop/pay/' + response.data.uuid);
  } else {
    console.error('Erreur lors de la création de la commande:', response.data);
  }
}
</script>