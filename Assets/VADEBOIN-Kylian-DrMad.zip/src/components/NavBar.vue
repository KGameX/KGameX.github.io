<template>
  <div>
    <table>
      <tbody>
      <tr>
        <td v-for="(link, index) in links" :key="index" :style="{paddingRight: '10px'}">
          <button
              @click="goTo(link.to)"
              class="nav-button"
          >
            <slot name="nav-button" :label="link.label">{{link.label}}</slot>
          </button>
        </td>
      </tr>
      </tbody>
    </table>
  </div>
</template>

<script setup>
/* ***************************
  IMPORTS
 *************************** */
import { useRouter } from 'vue-router'

/* ***************************
  PROPS
 *************************** */
defineProps({
  links: {
    type: Array,
    default: () => []
  }
})

/* ***************************
  COMPOSABLES
 *************************** */
const router = useRouter()

/* ***************************
  METHODS
 *************************** */
const goTo = (dest) => {
  router.push(dest)
}
</script>

<style scoped>
.nav-button {
  padding: 10px;
}
</style>