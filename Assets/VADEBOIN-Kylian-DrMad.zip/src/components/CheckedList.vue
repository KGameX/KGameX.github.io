<template>
  <div>
    <p v-for="(item, indexRow) in data" :key="indexRow">
      <input type="checkbox"
             v-if="itemCheck"
             :checked="checked[indexRow]"
             @click="$emit('checked-changed',indexRow)"
      >
      <span v-for="(field, indexCol) in fields" :key="indexCol">
        {{item[field]}}&nbsp
      </span>
      <input v-if="itemAmount" type="number" min="1" :value="amounts[indexRow]" @input="updateAmount(indexRow, $event.target.value)">
      <button v-if="itemButton && itemButton.show" color="grey" @click="$emit('item-button-clicked', {index: indexRow, amount: itemAmount ? amounts[indexRow] : 1})">{{itemButton.text}}</button>
    </p>
    <button v-if="listButton && listButton.show" color="green" @click="handleListButtonClick">{{listButton.text}}</button>
  </div>
</template>

<script setup>
/* ***************************
  PROPS
 *************************** */
const props = defineProps({
  data: Array, // les données sources
  fields: Array, // le tableau contenant le nom des champs à afficher
  itemCheck: Boolean, // s'il y a des case à cocher
  checked: Array, // le tableau des cases cochées
  itemButton: Object, // l'objet pour les boutons d'items
  listButton: Object, // l'objet pour le bouton de liste
  itemAmount: Boolean, // s'il y a des champs de quantité
})

/* ***************************
  EMITS
 *************************** */
const emit = defineEmits(['checked-changed', 'item-button-clicked', 'list-button-clicked'])

/* ***************************
  STATE
 *************************** */
import { ref, watch } from 'vue'
const amounts = ref([])

/* ***************************
  WATCHERS
 *************************** */
watch(() => props.data, (newData) => {
  amounts.value = new Array(newData.length).fill(1)
}, { immediate: true })

/* ***************************
  FUNCTIONS
 *************************** */
function updateAmount(index, value) {
  amounts.value[index] = parseInt(value) || 1
}

function handleListButtonClick() {
  if (props.itemCheck) {
    const selectedItems = []
    props.checked.forEach((isChecked, index) => {
      if (isChecked) {
        selectedItems.push({ index, amount: amounts.value[index] })
      }
    })
    emit('list-button-clicked', selectedItems)
  } else {
    emit('list-button-clicked')
  }
}
</script>